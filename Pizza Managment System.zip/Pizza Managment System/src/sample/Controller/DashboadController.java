package sample.Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class DashboadController {

    @FXML
    private Button btnitem;

    @FXML
    private Button btncustomer;

    @FXML
    void customer(ActionEvent event) throws IOException {

        Stage Customer = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("/sample/FXML/CustomerReg.fxml"));
        Customer.setResizable(false);
        Customer.setTitle("Customer Registration");
        Scene scene = new Scene(root, 700.0,600.0);
        Customer.setScene(scene);
        Customer.show();
    }

    @FXML
    void itempizza(ActionEvent event) throws IOException {

        Stage Pizza = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("/sample/FXML/Pizza.fxml"));
        Pizza.setResizable(false);
        Pizza.setTitle("Pizza Registration");
        Scene scene = new Scene(root, 700.0,600.0);
        Pizza.setScene(scene);
        Pizza.show();
    }

}
