package sample.Controller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {


    @FXML
    private TextField txtusername;

    @FXML
    private TextField ttxtpassword;

    @FXML
    private Button btnlogin;

    @FXML
    void Login(ActionEvent event) throws IOException {

        if(txtusername.getText().equals("farduus") && ttxtpassword.getText().equals("1234")){


            Stage Dashboad = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("/sample/FXML/Dashboad.fxml"));
            Dashboad.setMaximized(true);
            Dashboad.setTitle("Dashboad");
            Scene scene = new Scene(root, 400.0,600.0);
            Dashboad.setScene(scene);
            Dashboad.show();
        }

       else if(txtusername.getText().equals("hamda") && ttxtpassword.getText().equals("1122")){


            Stage Dashboad = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("/sample/FXML/Dashboad.fxml"));
            Dashboad.setMaximized(true);
            Dashboad.setTitle("Dashboad");
            Scene scene = new Scene(root, 400.0,600.0);
            Dashboad.setScene(scene);
            Dashboad.show();
        }

        else if(txtusername.getText().equals("ibraahim") && ttxtpassword.getText().equals("2233")){


            Stage Dashboad = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("/sample/FXML/Dashboad.fxml"));
            Dashboad.setMaximized(true);
            Dashboad.setTitle("Dashboad");
            Scene scene = new Scene(root, 400.0,600.0);
            Dashboad.setScene(scene);
            Dashboad.show();
        }

        else{
            Alert alert = new Alert(Alert.AlertType.ERROR,"Something Wrong ");
            alert.show();
            alert.setHeaderText("ERRor");

        }



    }
}
