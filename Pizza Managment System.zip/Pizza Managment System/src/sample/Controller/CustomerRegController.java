package sample.Controller;

import javafx.collections.FXCollections;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import sample.Models.Customers;
import sample.Models.Pizza;
import sample.PizzaDAO.PizzaDAO;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class CustomerRegController implements  Initializable {

    PizzaDAO pizzaDAO = new PizzaDAO();
    ArrayList<Customers> customers = new ArrayList<>();

    @FXML
    private AnchorPane txtsearch;

    @FXML
    private TableView<Customers> tblview;

    @FXML
    private TableColumn<Customers, Integer> colID;

    @FXML
    private TableColumn<Customers, String> colfirtname;

    @FXML
    private TableColumn<Customers, String> collastname;

    @FXML
    private TableColumn<Customers, Integer> colphone;

    @FXML
    private TableColumn<Customers, String> coladdress;

    @FXML
    private Button btnsave;

    @FXML
    private Button btnUpdate;

    @FXML
    private Button btndelete;

    @FXML
    private TextField txtfirst;

    @FXML
    private TextField txtphone;

    @FXML
    private TextField txtlast;

    @FXML
    private TextField txtaddress;

    @FXML
    private TextField txtsearch1;

    @FXML
    void search(KeyEvent event) {

        FilteredList<Customers> FLStudent = new FilteredList<>(FXCollections.observableList(customers), p->true);
        FLStudent.setPredicate(p->p.getFirstname().contains(txtsearch1.getText().toString().trim()));
        tblview.setItems(FLStudent);
    }

    public CustomerRegController() throws SQLException, ClassNotFoundException {
    }

    @FXML
    void Delete(ActionEvent event) throws SQLException, ClassNotFoundException {
        Customers DeleteCustomersId = tblview.getSelectionModel().getSelectedItem();
        if(DeleteCustomersId != null){
            pizzaDAO.DeleteCustomers(DeleteCustomersId);
            Alert alert = new Alert(Alert.AlertType.INFORMATION,"Deleted Successfully");
            alert.show();
            alert.setHeaderText("Delete");
            customers =  pizzaDAO.ReadCustoemrDetails();
            tblview.setItems(FXCollections.observableList(customers));
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR,"Not yet Selected");
            alert.show();
            alert.setHeaderText("Delete");
        }
    }



    @FXML
    void Mousehover(MouseEvent event) {
        Customers Cst =tblview.getSelectionModel().getSelectedItem();
        txtfirst.setText(Cst.getFirstname().toString());
        txtlast.setText(Cst.getLastname().toString());
        txtphone.setText(String.valueOf(Cst.getPhone()));
        txtaddress.setText(Cst.getAddress().toString());
    }

    @FXML
    void Update(ActionEvent event) throws SQLException, ClassNotFoundException {

        String Firstname = txtfirst.getText().toString();
        String Lastname = txtlast.getText().toString();
        int Phone = Integer.parseInt(txtphone.getText().toString());
        String Address = txtaddress.getText().toString();
        Customers cst = tblview.getSelectionModel().getSelectedItem();
        Customers cs = new Customers(Firstname,Lastname,Phone,Address);
        cs.setId(cst.getId());
        pizzaDAO.UpdateCustomers(cs);

        customers =  pizzaDAO.ReadCustoemrDetails();
        tblview.setItems(FXCollections.observableList(customers));
    }

    @FXML
    void save(ActionEvent event) throws SQLException, ClassNotFoundException {

        String Firstname = txtfirst.getText().toString();
        String Lastname = txtlast.getText().toString();
        int Phone = Integer.parseInt(txtphone.getText().toString());
        String Address = txtaddress.getText().toString();

        Customers cs = new Customers(Firstname,Lastname,Phone,Address);

        pizzaDAO.SaveCustomer(cs);

        customers =  pizzaDAO.ReadCustoemrDetails();
        tblview.setItems(FXCollections.observableList(customers));

    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            customers = pizzaDAO.ReadCustoemrDetails();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        tblview.setItems(FXCollections.observableList(customers));

        colID.setCellValueFactory(new PropertyValueFactory<Customers,Integer>("id"));
        colfirtname.setCellValueFactory(new PropertyValueFactory<Customers,String>("Firstname"));
        collastname.setCellValueFactory(new PropertyValueFactory<Customers,String>("Lastname"));
        colphone.setCellValueFactory(new PropertyValueFactory<Customers,Integer>("Phone"));
        coladdress.setCellValueFactory(new PropertyValueFactory<Customers,String>("Address"));



    }
}
