package sample.Controller;

import javafx.collections.FXCollections;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import sample.Models.Customers;
import sample.Models.Pizza;
import sample.PizzaDAO.PizzaDAO;

import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class PizzaController implements Initializable {

    PizzaDAO pizzaDAO = new PizzaDAO();
    ArrayList<Pizza> pizzas = new ArrayList<>();

    @FXML
    private TextField txtname;

    @FXML
    private TextField txttype;

    @FXML
    private TextField txtprice;

    @FXML
    private DatePicker txtdate;

    @FXML
    private Button btnsave;

    @FXML
    private Button btnUpdate;

    @FXML
    private Button btndelete;

    @FXML
    private TableView<Pizza> tblview;

    @FXML
    private TableColumn<Pizza, Integer> colID;

    @FXML
    private TableColumn<Pizza, String> colname;

    @FXML
    private TableColumn<Pizza, String> coltype;

    @FXML
    private TableColumn<Pizza, Integer> colprice;

    @FXML
    private TableColumn<Pizza,String> coldate;

    @FXML
    private TextField txtsearch;

    public PizzaController() throws SQLException, ClassNotFoundException {
    }

    @FXML
    void search(KeyEvent event) {

        FilteredList<Pizza> FLStudent = new FilteredList<>(FXCollections.observableList(pizzas), p->true);
        FLStudent.setPredicate(p->p.getName().contains(txtsearch.getText().toString().trim()));
        tblview.setItems(FLStudent);
    }


    @FXML
    void Delete(ActionEvent event) throws SQLException, ClassNotFoundException {

        Pizza DeletepizzaId = tblview.getSelectionModel().getSelectedItem();
        if(DeletepizzaId != null){
            pizzaDAO.Deletepizza(DeletepizzaId);
            Alert alert = new Alert(Alert.AlertType.INFORMATION,"Deleted Successfully");
            alert.show();
            alert.setHeaderText("Delete");
            pizzas =  pizzaDAO.ReadpizzaDetails();
            tblview.setItems(FXCollections.observableList(pizzas));
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR,"Not yet Selected");
            alert.show();
            alert.setHeaderText("Delete");
        }
    }


    @FXML
    void Mousehover(MouseEvent event) {
        Pizza ps =tblview.getSelectionModel().getSelectedItem();
        txtname.setText(ps.getName().toString());
        txttype.setText(ps.getType().toString());
        txtprice.setText(String.valueOf(ps.getPrice()));
        String  date =ps.getDate();
        txtdate.setValue(LocalDate.parse(date));

    }


    @FXML
    void Update(ActionEvent event) throws SQLException, ClassNotFoundException {

        String Name = txtname.getText().toString();
        String type = txttype.getText().toString();
        int Price = Integer.parseInt(txtprice.getText().toString());
        String date = txtdate.getValue().toString();
        Pizza ps = tblview.getSelectionModel().getSelectedItem();
        Pizza pizza = new Pizza(Name,type,Price,date);
        pizza.setId(ps.getId());

        pizzaDAO.Updatepizza(pizza);
        pizzas =  pizzaDAO.ReadpizzaDetails();
        tblview.setItems(FXCollections.observableList(pizzas));
    }

    @FXML
    void save(ActionEvent event) throws SQLException, ClassNotFoundException {

        String Name = txtname.getText().toString();
        String type = txttype.getText().toString();
        int Price = Integer.parseInt(txtprice.getText().toString());
        String date = txtdate.getValue().toString();

        Pizza pizza = new Pizza(Name,type,Price,date);

        pizzaDAO.SavePizza(pizza);
        pizzas =  pizzaDAO.ReadpizzaDetails();
        tblview.setItems(FXCollections.observableList(pizzas));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            pizzas = pizzaDAO.ReadpizzaDetails();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        tblview.setItems(FXCollections.observableList(pizzas));

        colID.setCellValueFactory(new PropertyValueFactory<Pizza,Integer>("id"));
        colname.setCellValueFactory(new PropertyValueFactory<Pizza,String>("Name"));
        coltype.setCellValueFactory(new PropertyValueFactory<Pizza,String>("Type"));
        colprice.setCellValueFactory(new PropertyValueFactory<Pizza, Integer>("Price"));
        coldate.setCellValueFactory(new PropertyValueFactory<Pizza,String>("Date"));
    }
}
