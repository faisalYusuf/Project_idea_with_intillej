package sample.PizzaDAO;

import javafx.scene.control.Alert;
import sample.Connection.Connections;
import sample.Models.Customers;
import sample.Models.Pizza;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class PizzaDAO {

    private static Connection connection;

    public PizzaDAO() throws SQLException, ClassNotFoundException {
        connection = Connections.setConnection();
    }


    public void SaveCustomer(Customers cs) throws SQLException {

        String sql = "INSERT INTO customer(firstname,Lastname,Phone,Address) " +
                "VALUES('"+cs.getFirstname() + "', '"+cs.getLastname() +"', "+cs.getPhone() +", '"+cs.getAddress() +"') ";
        Statement statement = connection.createStatement();
        int r = statement.executeUpdate(sql);
//        System.out.println(sql);
        if(r > 0){
            Alert alert = new Alert(Alert.AlertType.INFORMATION,"inserted");
            alert.setHeaderText("Success");
            alert.show();
//                   System.out.println(sql);
        }else{
            Alert alert = new Alert(Alert.AlertType.WARNING,"SomeThing Error");
            alert.setHeaderText("ERROR");
            alert.show();
        }

    }


    // Read Customer Details

    public ArrayList<Customers> ReadCustoemrDetails() throws SQLException, ClassNotFoundException {
        ArrayList<Customers> customers = new ArrayList<>();
        String sql = "SELECT * FROM customer";
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery(sql);

        while(rs.next()){
            customers.add(ConvertData(rs));
        }

        return  customers;
    }

    public Customers ConvertData(ResultSet rs) throws SQLException, ClassNotFoundException {
        Customers customers = new Customers();

        customers.setId(rs.getInt("ID"));
        customers.setFirstname(rs.getString("Firstname"));
        customers.setLastname(rs.getString("Lastname"));
        customers.setPhone(rs.getInt("Phone"));
        customers.setAddress(rs.getString("Address"));

        return  customers;

    }


    public void DeleteCustomers(Customers cs) throws SQLException {

        String sql = "DELETE FROM customer WHERE ID='"+cs.getId()+"'";
        Statement statement = connection.createStatement();
        statement.executeUpdate(sql);


    }

    // Update Customers

    public void UpdateCustomers(Customers cst) throws SQLException {

        String sql = "Update customer SET Firstname='"+cst.getFirstname() +"', Lastname='"+cst.getLastname()+"', Phone='"+cst.getPhone()+"', Address='"+cst.getAddress()+ "' WHERE ID ='"+cst.getId()+ "' ";
//        System.out.println(sql);
        Statement statement = connection.createStatement();
        int r = statement.executeUpdate(sql);
        if(r > 0){
            Alert alert = new Alert(Alert.AlertType.INFORMATION,"Updated Successfully");
            alert.show();
            alert.setHeaderText("Update");
        }else{
            Alert alert = new Alert(Alert.AlertType.WARNING,"Not Yet Selected ");
            alert.show();
            alert.setHeaderText("Update");
        }
    }




                        /// Working With Tables Pizza
   ///________  _______  ________  _________ _______ ___________  _________________   _____________   ________


    public void SavePizza(Pizza ps) throws SQLException {

        String sql = "INSERT INTO itempizza(Pizza_name,Pizza_Type,Pizza_Price,Pizza_Date) " +
                "VALUES('"+ps.getName() + "', '"+ps.getType() +"', "+ps.getPrice() +", '"+ps.getDate() +"') ";
        Statement statement = connection.createStatement();
        int r = statement.executeUpdate(sql);
//        System.out.println(sql);
        if(r > 0){
            Alert alert = new Alert(Alert.AlertType.INFORMATION,"Inserted Saccussfully ");
            alert.setHeaderText("Success");
            alert.show();
//                   System.out.println(sql);
        }else{
            Alert alert = new Alert(Alert.AlertType.WARNING,"SomeThing Error");
            alert.setHeaderText("ERROR");
            alert.show();
        }

    }


    // Read Customer Details

    public ArrayList<Pizza> ReadpizzaDetails() throws SQLException, ClassNotFoundException {
        ArrayList<Pizza> pizzas = new ArrayList<>();
        String sql = "SELECT * FROM itempizza";
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery(sql);

        while(rs.next()){
            pizzas.add(ConvertDatapizza(rs));
        }

        return  pizzas;
    }

    public Pizza ConvertDatapizza(ResultSet rs) throws SQLException, ClassNotFoundException {
        Pizza pizza = new Pizza();

        pizza.setId(rs.getInt("ID"));
        pizza.setName(rs.getString("Pizza_name"));
        pizza.setType(rs.getString("Pizza_Type"));
        pizza.setPrice(rs.getInt("Pizza_Price"));
        pizza.setDate(rs.getString("Pizza_Date"));

        return  pizza;

    }



    public void Deletepizza(Pizza cs) throws SQLException {

        String sql = "DELETE FROM itempizza WHERE ID='"+cs.getId()+"'";
        Statement statement = connection.createStatement();
        statement.executeUpdate(sql);


    }


    // Update Items

    public void Updatepizza(Pizza ps) throws SQLException {

        String sql = "Update itempizza SET Pizza_name='"+ps.getName() +"', Pizza_Type='"+ps.getType()+"', Pizza_Price='"+ps.getPrice()+"', Pizza_Date='"+ps.getDate()+ "' WHERE ID ='"+ps.getId()+ "' ";
//        System.out.println(sql);
        Statement statement = connection.createStatement();
        int r = statement.executeUpdate(sql);
        if(r > 0){
            Alert alert = new Alert(Alert.AlertType.INFORMATION,"Updated Successfully");
            alert.show();
            alert.setHeaderText("Update");
        }else{
            Alert alert = new Alert(Alert.AlertType.WARNING,"Some Thing Go Wrong  ");
            alert.show();
            alert.setHeaderText("Update");
        }
    }




}
