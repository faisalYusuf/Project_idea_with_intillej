package Store.Controller;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class DashboadController {

    @FXML
    private Button btnCustomer;

    @FXML
    private Button btnProduct;

    @FXML
    void Customer(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/Store/FXML/CustomerRegisteration.fxml"));
        Stage AddNewCustomer = new Stage();
        AddNewCustomer.setTitle("Customer Registration");
        Scene scene = new Scene(root,800.0,500.0);
        AddNewCustomer.setScene(scene);
        AddNewCustomer.setResizable(false);
        AddNewCustomer.show();
    }

    @FXML
    void Product(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/Store/FXML/ItemRegistration.fxml"));
        Stage AddNewCustomer = new Stage();
        AddNewCustomer.setTitle("Items Registration");
        Scene scene = new Scene(root,800.0,500.0);
        AddNewCustomer.setScene(scene);
        AddNewCustomer.setResizable(false);
        AddNewCustomer.show();
    }

}
