package Store.Controller;

import Store.DAO.StoreDAO;
import Store.Models.Customers;
import Store.Models.Items;
import javafx.collections.FXCollections;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.awt.*;
import java.net.URL;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

public class ItemRegistrationController implements Initializable {

    StoreDAO storeDAO = new StoreDAO();
    ArrayList<Items> items = new ArrayList<>();
    @FXML
    private TextField txtname;

    @FXML
    private TextField txtprice;

    @FXML
    private TextField txtquantity;

    @FXML
    private TableView<Items> tblview;

    @FXML
    private TableColumn<Items, Integer> ColomnID;

    @FXML
    private TableColumn<Items, String> Colomnname;

    @FXML
    private TableColumn<Items, Integer> ColomnPrice;

    @FXML
    private TableColumn<Items, Integer> ColomnQuantity;

    @FXML
    private TableColumn<Items, DatePicker> ColomnDate;

    @FXML
    private Button btnsave;

    @FXML
    private Button bbtnUpdate;

    @FXML
    private Button btnDelete;
    @FXML
    private DatePicker txtdate;

    @FXML
    private TextField txtsearch;

    @FXML
    void search(KeyEvent event) {
        FilteredList<Items> FLStudent = new FilteredList<>(FXCollections.observableList(items), p->true);
        FLStudent.setPredicate(p->p.getName().contains(txtsearch.getText().toString().trim()));
        tblview.setItems(FLStudent);
    }


    public ItemRegistrationController() throws SQLException, ClassNotFoundException {
    }

    @FXML
    void Delete(ActionEvent event) throws SQLException {

        Items ItemID = tblview.getSelectionModel().getSelectedItem();
        if(ItemID != null){
            storeDAO.DeleteItems(ItemID);
            Alert alert = new Alert(Alert.AlertType.INFORMATION,"Deleted Successfully");
            alert.show();
            alert.setHeaderText("Delete");
            items = storeDAO.Readitens();
            tblview.setItems(FXCollections.observableList(items));
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR,"Not yet Selected");
            alert.show();
            alert.setHeaderText("Delete");
        }
    }
    @FXML
    void rowclick(MouseEvent event) throws SQLException, ClassNotFoundException {
        Items item =tblview.getSelectionModel().getSelectedItem();
        txtname.setText(item.getName().toString());
        txtprice.setText(String.valueOf(item.getPrice()));
        txtquantity.setText(String.valueOf(item.getQuantity()));
        String  date =item.getDate();
        txtdate.setValue(LocalDate.parse(date));

    }
    @FXML
    void Save(ActionEvent event) throws SQLException {

        String Name = txtname.getText().toString();
        int Price = Integer.parseInt(txtprice.getText().toString());
        int Quantity = Integer.parseInt(txtquantity.getText().toString());
        String date = txtdate.getValue().toString();

        Items item = new Items(Name,Price,Quantity,date);
        storeDAO.saveditems(item);
        items = storeDAO.Readitens();
        tblview.setItems(FXCollections.observableList(items));

    }

    @FXML
    void Update(ActionEvent event) throws SQLException, NoSuchFieldException {
        String Name = txtname.getText().toString();
        int Price = Integer.parseInt(txtprice.getText().toString());
        int Quantity = Integer.parseInt(txtquantity.getText().toString());
        String date = txtdate.getValue().toString();
        Items id = tblview.getSelectionModel().getSelectedItem();
        Items item = new Items(Name,Price,Quantity,date);
        item.setId(id.getId());
        storeDAO.UpdateItem(item);

        items = storeDAO.Readitens();
        tblview.setItems(FXCollections.observableList(items));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        try {
            items = storeDAO.Readitens();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        tblview.setItems(FXCollections.observableList(items));

        ColomnID.setCellValueFactory(new PropertyValueFactory<Items,Integer>("Id"));
        Colomnname.setCellValueFactory(new PropertyValueFactory<Items, String>("Name"));
        ColomnQuantity.setCellValueFactory(new PropertyValueFactory<Items,Integer>("Quantity"));
        ColomnPrice.setCellValueFactory(new PropertyValueFactory<Items,Integer>("Price"));
        ColomnDate.setCellValueFactory(new PropertyValueFactory<Items,DatePicker>("Date"));
        tblview.setEditable(true);

    }
}
