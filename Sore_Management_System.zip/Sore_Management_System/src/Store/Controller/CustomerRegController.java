package Store.Controller;

import Store.DAO.StoreDAO;
import Store.Models.Customers;
import Store.Models.Items;
import javafx.collections.FXCollections;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class CustomerRegController implements Initializable {
    StoreDAO storeDAO = new StoreDAO();
    ArrayList<Customers>  customers = new ArrayList<>();
    @FXML
    private TextField txtfirst;

    @FXML
    private TextField txtlast;

    @FXML
    private TextField txtphone;

    @FXML
    private TextField txtaddress;

    @FXML
    private TextField txtpayment;

    @FXML
    private TableView<Customers> tblview;


    @FXML
    private TableColumn<Customers, Integer> ClolumnID;

    @FXML
    private TableColumn<Customers, String> ClolumnFirstname;

    @FXML
    private TableColumn<Customers, String> ClolumnLastname;

    @FXML
    private TableColumn<Customers, Integer> ClolumnPhone;

    @FXML
    private TableColumn<Customers, String> ClolumnAddress;

    @FXML
    private TableColumn<Customers, Integer> ClolumnPayment;

    @FXML
    private Button btnsave;

    @FXML
    private Button bbtnUpdate;

    @FXML
    private Button btnDelete;

    @FXML
    private TextField txtsearch;

    public CustomerRegController() throws SQLException, ClassNotFoundException {
    }

    @FXML
    void Search(KeyEvent event) {
        FilteredList<Customers> FLStudent = new FilteredList<>(FXCollections.observableList(customers), p->true);
        FLStudent.setPredicate(p->p.getFirstname().contains(txtsearch.getText().toString().trim()));
        tblview.setItems(FLStudent);
    }

    @FXML
        void Delete(ActionEvent event) throws SQLException {

            Customers DeleteCustomersId = tblview.getSelectionModel().getSelectedItem();
            if(DeleteCustomersId != null){
                storeDAO.DeleteCustomers(DeleteCustomersId);
                Alert alert = new Alert(Alert.AlertType.INFORMATION,"Deleted Successfully");
                alert.show();
                alert.setHeaderText("Delete");
                customers =  storeDAO.ReadCustoemrDetails();
                tblview.setItems(FXCollections.observableList(customers));
            }else{
                Alert alert = new Alert(Alert.AlertType.ERROR,"Not yet Selected");
                alert.show();
                alert.setHeaderText("Delete");
            }
        }

    @FXML
    void Save(ActionEvent event) throws SQLException {

        String Firstname = txtfirst.getText().toString();
        String Lastname = txtlast.getText().toString();
        int Phone = Integer.parseInt(txtphone.getText().toString());
        String Address = txtaddress.getText().toString();
        int Payment = Integer.parseInt(txtpayment.getText().toString());

        Customers cs = new Customers(Firstname,Lastname,Phone,Address,Payment);

        storeDAO.SaveCustomer(cs);
        customers =  storeDAO.ReadCustoemrDetails();
        tblview.setItems(FXCollections.observableList(customers));

    }

    @FXML
    void rowclick(MouseEvent event) throws SQLException, ClassNotFoundException {
        Customers Cst =tblview.getSelectionModel().getSelectedItem();
        txtfirst.setText(Cst.getFirstname().toString());
        txtlast.setText(Cst.getFirstname().toString());
        txtphone.setText(String.valueOf(Cst.getPhone()));
        txtaddress.setText(Cst.getAddress().toString());
        txtpayment.setText(String.valueOf(Cst.getPayment()));

    }

    @FXML
    void Update(ActionEvent event) throws SQLException {

        String Firstname = txtfirst.getText().toString();
        String Lastname = txtlast.getText().toString();
        int Phone = Integer.parseInt(txtphone.getText().toString());
        String Address = txtaddress.getText().toString();
        int Payment = Integer.parseInt(txtpayment.getText().toString());
        Customers cst = tblview.getSelectionModel().getSelectedItem();
        Customers cs = new Customers(Firstname,Lastname,Phone,Address,Payment);
        cs.setId(cst.getId());
        storeDAO.UpdateCustomers(cs);
        customers =  storeDAO.ReadCustoemrDetails();
        tblview.setItems(FXCollections.observableList(customers));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            customers = storeDAO.ReadCustoemrDetails();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        tblview.setItems(FXCollections.observableList(customers));

        ClolumnID.setCellValueFactory(new PropertyValueFactory<Customers,Integer>("Id"));
        ClolumnFirstname.setCellValueFactory(new PropertyValueFactory<Customers,String>("Firstname"));
        ClolumnLastname.setCellValueFactory(new PropertyValueFactory<Customers,String>("Lastname"));
        ClolumnPhone.setCellValueFactory(new PropertyValueFactory<Customers,Integer>("Phone"));
        ClolumnAddress.setCellValueFactory(new PropertyValueFactory<Customers,String>("Address"));
        ClolumnPayment.setCellValueFactory(new PropertyValueFactory<Customers,Integer>("Payment"));

        tblview.setEditable(true);

        ClolumnFirstname.setCellFactory(TextFieldTableCell.forTableColumn());
        ClolumnLastname.setCellFactory(TextFieldTableCell.forTableColumn());
//        ClolumnPhone.setCellFactory(TextFieldTableCell.forTableColumn());
        ClolumnAddress.setCellFactory(TextFieldTableCell.forTableColumn());
//        ClolumnPayment.setCellFactory(TextFieldTableCell.forTableColumn());
    }
}
