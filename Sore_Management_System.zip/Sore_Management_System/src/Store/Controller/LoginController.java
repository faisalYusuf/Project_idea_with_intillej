package Store.Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField txtusername;

    @FXML
    private TextField txtpassword;

    @FXML
    private Button btnlogin;

    @FXML
    void Login(ActionEvent event) throws IOException {
        if(txtusername.getText().equals("") && txtpassword.getText().equals("")){
            Alert alert = new Alert(Alert.AlertType.ERROR,"Empty Username and Password ");
            alert.show();
            alert.setHeaderText("ERROR");
        }

        else if(txtusername.getText().equals("") && txtpassword.getText().equals("1234")){
            Alert alert = new Alert(Alert.AlertType.ERROR,"Username Empty ");
            alert.show();
            alert.setHeaderText("ERROR");
        }

        else if(txtusername.getText().equals("faisal") && txtpassword.getText().equals("")){
            Alert alert = new Alert(Alert.AlertType.ERROR,"Password Empty ");
            alert.show();
            alert.setHeaderText("ERROR");
        }

       else if(txtusername.getText().equals("faisal") && txtpassword.getText().equals("1234")){
            Stage stage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("/Store/FXML/Dashboad.fxml"));
            stage.setTitle("Dashboad");
            Scene scene = new Scene(root,600.0, 400.0);
            stage.setMaximized(true);
            stage.setScene(scene);
            stage.show();
        }

       else if(txtusername.getText().equals("Mohamed") && txtpassword.getText().equals("1234")){
            Stage stage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("/Store/FXML/Dashboad.fxml"));
            stage.setTitle("Dashboad");
            Scene scene = new Scene(root,600.0, 400.0);
            stage.setMaximized(true);
            stage.setScene(scene);
            stage.show();
        }
        else if(txtusername.getText().equals("Yasin") && txtpassword.getText().equals("1234")){
            Stage stage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("/Store/FXML/Dashboad.fxml"));
            stage.setTitle("Dashboad");
            Scene scene = new Scene(root,600.0, 400.0);
            stage.setMaximized(true);
            stage.setScene(scene);
            stage.show();
        }
        else if(txtusername.getText().equals("Xamsa") && txtpassword.getText().equals("1234")){
            Stage stage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("/Store/FXML/Dashboad.fxml"));
            stage.setTitle("Dashboad");
            Scene scene = new Scene(root,600.0, 400.0);
            stage.setMaximized(true);
            stage.setScene(scene);
            stage.show();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR,"Username Or Password Wrong ");
            alert.show();
            alert.setHeaderText("ERROR");
        }

    }

}
