package Store.DatabaseConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static final String driver = "com.mysql.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost/store";
    private static final String user = "root";
    private static final String pass = "";

    private static Connection connection;

    public static Connection setConnection() throws ClassNotFoundException, SQLException {
        Class.forName(driver);
        // Stabilise and pass parameters
        connection = DriverManager.getConnection(dbUrl,user,pass);

        return  connection;
    }


}
