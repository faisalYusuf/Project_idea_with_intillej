package Store.Models;

public class Customers {

    private int id;
    private  String Firstname;
    private String Lastname;
    private int phone;
    private  String Address;
    private int Payment;

    public Customers(String firstname, String lastname, int phone, String address, int payment) {
        this.Firstname = firstname;
        this.Lastname = lastname;
        this.phone = phone;
        this.Address = address;
        this.Payment = payment;
    }

    public Customers() {

    }



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstname() {
        return Firstname;
    }

    public void setFirstname(String firstname) {
        Firstname = firstname;
    }

    public String getLastname() {
        return Lastname;
    }

    public void setLastname(String lastname) {
        Lastname = lastname;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public int getPayment() {
        return Payment;
    }

    public void setPayment(int payment) {
        Payment = payment;
    }
}
