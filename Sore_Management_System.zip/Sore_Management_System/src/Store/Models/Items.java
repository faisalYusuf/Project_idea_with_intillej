package Store.Models;

import java.util.Date;

public class Items {

    private  int id;
    private  String name;
    private int Price;
    private int Quantity;
    private String date;

    public Items(String name, int price, int Quantity, String date) {
        this.name = name;
        this.Price = price;
        this.Quantity = Quantity;
        this.date = date;
    }

    public Items() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return Price;
    }

    public void setPrice(int price) {
        Price = price;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        Quantity = quantity;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
