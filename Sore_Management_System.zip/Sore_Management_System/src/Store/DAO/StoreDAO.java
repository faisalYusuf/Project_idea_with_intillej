package Store.DAO;

import Store.DatabaseConnection.DBConnection;
import Store.Models.Customers;
import Store.Models.Items;
import javafx.scene.control.Alert;

import java.sql.*;
import java.util.ArrayList;

public class StoreDAO {
    private static Connection connection;

    public StoreDAO() throws SQLException, ClassNotFoundException {
        connection  = DBConnection.setConnection();
    }

    public void SaveCustomer(Customers cs) throws SQLException {

        String sql = "INSERT INTO customers(Firstnamr,Lastname,Phone,Address,Payment) " +
                "VALUES('"+cs.getFirstname() + "', '"+cs.getLastname() +"', "+cs.getPhone() +", '"+cs.getAddress() +"',"+cs.getPayment() +" ) ";
        Statement statement = connection.createStatement();
        int r = statement.executeUpdate(sql);
//        System.out.println(sql);
        if(r > 0){
            Alert alert = new Alert(Alert.AlertType.INFORMATION,"inserted");
            alert.setHeaderText("Success");
            alert.show();
//                   System.out.println(sql);
        }else{
            System.out.println("Something Error");
        }

    }

    // Read Customer Details

    public ArrayList<Customers> ReadCustoemrDetails() throws SQLException {
        ArrayList<Customers> customers = new ArrayList<>();
        String sql = "SELECT * FROM customers";
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery(sql);

        while(rs.next()){
            customers.add(ConvertData(rs));
        }

        return  customers;
    }

    public Customers ConvertData(ResultSet rs) throws SQLException {
        Customers customers = new Customers();
        customers.setId(rs.getInt("ID"));
        customers.setFirstname(rs.getString("Firstnamr"));
        customers.setLastname(rs.getString("Lastname"));
        customers.setPhone(rs.getInt("Phone"));
        customers.setAddress(rs.getString("Address"));
        customers.setPayment(rs.getInt("Payment"));

        return customers;

    }


    public void DeleteCustomers(Customers cs) throws SQLException {

        String sql = "DELETE FROM customers WHERE ID='"+cs.getId()+"'";
        Statement statement = connection.createStatement();
        statement.executeUpdate(sql);


    }

    // Update Items

    public void UpdateCustomers(Customers cst) throws SQLException {

        String sql = "Update customers SET Firstnamr='"+cst.getFirstname() +"', Lastname='"+cst.getLastname()+"', Phone='"+cst.getPhone()+"', Address='"+cst.getAddress()+ "' , Payment='"+cst.getPayment()+ "' WHERE ID ='"+cst.getId()+ "' ";
//        System.out.println(sql);
        Statement statement = connection.createStatement();
        int r = statement.executeUpdate(sql);
        if(r > 0){
            Alert alert = new Alert(Alert.AlertType.INFORMATION,"Updated Successfully");
            alert.show();
            alert.setHeaderText("Update");
        }else{
            Alert alert = new Alert(Alert.AlertType.WARNING,"Not Yet Selected ");
            alert.show();
            alert.setHeaderText("Update");
        }
    }






    // Information About Item Details

    public void saveditems(Items items) throws SQLException {

        String sql = "INSERT INTO items(Name,Price,Quantity,Date) " +
                "VALUES('" + items.getName() + "', '" + items.getPrice() + "', " + items.getQuantity() + ", '" + items.getDate() + "' ) ";
        Statement statement = connection.createStatement();
        int r = statement.executeUpdate(sql);
        System.out.println(sql);
        if (r > 0) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "inserted");
            alert.setHeaderText("Success");
            alert.show();
//                   System.out.println(sql);
        } else {
            System.out.println("Something Error");
        }
    }

    // Read item details
    public ArrayList<Items> Readitens() throws SQLException {
        ArrayList<Items> items = new ArrayList<>();
        String sql = "SELECT * FROM items";
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery(sql);

        while(rs.next()){
            items.add(ConvertDataitems(rs));
        }

        return  items;
    }

    public Items ConvertDataitems(ResultSet rs) throws SQLException {
        Items items = new Items();
        items.setId(rs.getInt("ID"));
        items.setName(rs.getString("Name"));
        items.setPrice(rs.getInt("Price"));
        items.setQuantity(rs.getInt("Quantity"));
        items.setDate(rs.getString("Date"));

        return items;

    }
    // Update Items

    public void UpdateItem(Items item) throws SQLException {

        String sql = "Update items SET Name='"+item.getName() +"', Price='"+item.getPrice()+"', Quantity='"+item.getQuantity()+"', Date='"+item.getDate()+ "' WHERE ID ='"+item.getId()+ "' ";
//        System.out.println(sql);
        Statement statement = connection.createStatement();
        int r = statement.executeUpdate(sql);
        if(r > 0){
            Alert alert = new Alert(Alert.AlertType.INFORMATION,"Updated Successfully");
            alert.show();
            alert.setHeaderText("Update");
        }else{
            Alert alert = new Alert(Alert.AlertType.WARNING,"Not Yet Selected ");
            alert.show();
            alert.setHeaderText("Update");
        }
    }

    // Delete Items

    public void DeleteItems(Items item) throws SQLException {

        String sql = "DELETE FROM items WHERE ID='"+item.getId()+"'";
        Statement statement = connection.createStatement();
        statement.executeUpdate(sql);
    }

}
